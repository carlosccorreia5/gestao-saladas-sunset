export function Test() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>✅ Dependências instaladas com sucesso!</h1>
      <ul>
        <li>React: OK</li>
        <li>React Router: OK</li>
        <li>Supabase: OK</li>
        <li>Date-fns: OK</li>
        <li>Recharts: OK</li>
        <li>Lucide React: OK</li>
      </ul>
    </div>
  )
}
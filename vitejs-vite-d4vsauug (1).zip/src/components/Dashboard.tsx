export function Dashboard() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Dashboard (em construção)</h1>
      <button onClick={() => window.location.href = '/'}>
        Voltar para Login
      </button>
    </div>
  )
}
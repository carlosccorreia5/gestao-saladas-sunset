// Esta é uma versão SIMPLIFICADA que vai funcionar

const supabaseUrl = 'https://seu-projeto.supabase.co'; // SUBSTITUA pela SUA URL
const supabaseAnonKey = 'sua-chave-anon-aqui'; // SUBSTITUA pela SUA CHAVE

export const supabase = {
  auth: {
    getSession: () => Promise.resolve({ data: { session: null } }),
    onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } })
  },
  from: (table: string) => ({
    select: () => Promise.resolve({ data: [], error: null }),
    insert: () => Promise.resolve({ error: null }),
    update: () => Promise.resolve({ error: null }),
    delete: () => Promise.resolve({ error: null })
  })
};